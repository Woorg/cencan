head: {
    defaults: {
        title: 'Main page',
        useSocialMetaTags: false
    },
    // inner: {
    //     title: 'Inner page',
    //     useSocialMetaTags: false
    // },
    // university: {
    //     title: 'University page',
    //     useSocialMetaTags: false
    // }
}