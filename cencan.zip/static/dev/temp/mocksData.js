'head': {
    defaults: {
        title: 'Main page',
        useSocialMetaTags: false
    },
    // inner: {
    //     title: 'Inner page',
    //     useSocialMetaTags: false
    // },
    // university: {
    //     title: 'University page',
    //     useSocialMetaTags: false
    // }
},

__iconsData: {
    
        'android-icon': {
            width: '18px',
            height: '22px'
        },
    
        'arrow': {
            width: '13px',
            height: '14px'
        },
    
        'calendar-icon': {
            width: '21px',
            height: '23px'
        },
    
        'clock-icon': {
            width: '512px',
            height: '512px'
        },
    
        'edit-icon': {
            width: '19px',
            height: '20px'
        },
    
        'exhibitors-icon-2': {
            width: '22px',
            height: '18px'
        },
    
        'exhibitors-icon-3': {
            width: '24px',
            height: '22px'
        },
    
        'exhibitors-icon-4': {
            width: '24px',
            height: '23px'
        },
    
        'fb-icon': {
            width: '11px',
            height: '21px'
        },
    
        'hero-img-1': {
            width: '389px',
            height: '269px'
        },
    
        'hero-img-2': {
            width: '411px',
            height: '385px'
        },
    
        'hero-img-3': {
            width: '354px',
            height: '288px'
        },
    
        'instagram-icon': {
            width: '19px',
            height: '20px'
        },
    
        'iphone-icon': {
            width: '18px',
            height: '21px'
        },
    
        'linkedin-icon': {
            width: '19px',
            height: '20px'
        },
    
        'marker-icon': {
            width: '384px',
            height: '512px'
        },
    
        'menu': {
            width: '512px',
            height: '512px'
        },
    
        'question-icon': {
            width: '512px',
            height: '512px'
        },
    
        'rss-icon': {
            width: '19px',
            height: '20px'
        },
    
        'search-icon': {
            width: '11px',
            height: '16px'
        },
    
        'star-icon': {
            width: '21px',
            height: '21px'
        },
    
        'twitter-icon': {
            width: '20px',
            height: '16px'
        },
    
        'youtube-icon': {
            width: '22px',
            height: '16px'
        },
    
},

__pages: [{
                name: 'demo',
                href: 'demo.html'
             },{
                name: 'demos',
                href: 'demos.html'
             },{
                name: 'exhibitors',
                href: 'exhibitors.html'
             },{
                name: 'featured',
                href: 'featured.html'
             },{
                name: 'index-energy',
                href: 'index-energy.html'
             },{
                name: 'index-forestry',
                href: 'index-forestry.html'
             },{
                name: 'index-mining',
                href: 'index-mining.html'
             },{
                name: 'index',
                href: 'index.html'
             },{
                name: 'technical',
                href: 'technical.html'
             }]